# Shizuku instantiates this by name inside the shell process
-keep class com.gamebooster.ShellService { <init>(); }
-keep class com.gamebooster.IShellService { *; }
-keep class com.gamebooster.IShellService$Stub { *; }
