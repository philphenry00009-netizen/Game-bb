package com.gamebooster;

interface IShellService {
    void destroy() = 16777114;          // reserved transaction id required by Shizuku
    String exec(String command) = 1;    // runs `sh -c command` as shell (uid 2000) or root
}
