package com.gamebooster;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Builds and runs the boost / restore shell batches (one exec each = minimal overhead). */
final class Boost {

    static final String CODM = "com.activision.callofduty.shooter";
    static final int TARGET_WIDTH = 720;

    /** Edit freely. Only list apps you don't need running during a match. */
    static final String[] KILL = {
            "com.facebook.katana", "com.facebook.orca", "com.instagram.android",
            "com.zhiliaoapp.musically", "com.snapchat.android", "com.google.android.youtube",
            "com.android.chrome", "com.netflix.mediaclient"
    };

    private static final Pattern PHYS = Pattern.compile("Physical size:\\s*(\\d+)x(\\d+)");

    static String boost(IShellService s) throws Exception {
        StringBuilder cmd = new StringBuilder();

        // 1. Resolution downscale (keeps aspect ratio, even height)
        Matcher m = PHYS.matcher(s.exec("wm size"));
        if (m.find()) {
            int w = Integer.parseInt(m.group(1)), h = Integer.parseInt(m.group(2));
            if (w > TARGET_WIDTH) {
                int nh = Math.round(h * (float) TARGET_WIDTH / w);
                nh -= nh % 2;
                cmd.append("wm size ").append(TARGET_WIDTH).append('x').append(nh).append("; ");
            }
        }

        // 2. Kill window blur
        cmd.append("settings put global disable_window_blurs 1; ");

        // 3. Free RAM: drop cached processes, then force-stop heavy apps
        cmd.append("am kill-all; ");
        for (String pkg : KILL) cmd.append("am force-stop ").append(pkg).append("; ");

        // 4. Launch CODM
        cmd.append("monkey -p ").append(CODM).append(" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1");

        return s.exec(cmd.toString());
    }

    static String restore(IShellService s) throws Exception {
        return s.exec("wm size reset; settings put global disable_window_blurs 0");
    }
}
