package com.gamebooster;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int REQ_SHIZUKU = 1;
    private static final int BG = 0xFF0B0B0F, CARD = 0xFF16161D, ACCENT = 0xFF00C853, DIM = 0xFF8A8A96;

    private TextView status, log;
    private Button bPerm, bBoost, bRestore;

    private final Shizuku.OnBinderReceivedListener onBinder = () -> runOnUiThread(this::refresh);
    private final Shizuku.OnBinderDeadListener onDead = () -> runOnUiThread(this::refresh);
    private final Shizuku.OnRequestPermissionResultListener onPerm = (c, r) -> runOnUiThread(this::refresh);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(onBinder);
        Shizuku.addBinderDeadListener(onDead);
        Shizuku.addRequestPermissionResultListener(onPerm);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder);
        Shizuku.removeBinderDeadListener(onDead);
        Shizuku.removeRequestPermissionResultListener(onPerm);
        super.onDestroy();
    }

    // ---------- actions ----------
    private void onBoost() {
        if (getPackageManager().getLaunchIntentForPackage(Boost.CODM) == null) {
            log("CODM (" + Boost.CODM + ") is not installed.");
            return;
        }
        final Context app = getApplicationContext();
        log("Boosting…");
        ShizukuHelper.with(s -> {
            String out = Boost.boost(s);
            Notifier.show(app);
            runOnUiThread(() -> log("Boost applied.\n" + out.trim()));
        }, e -> runOnUiThread(() -> log("Error: " + e)));
    }

    private void onRestore() {
        final Context app = getApplicationContext();
        ShizukuHelper.with(s -> {
            Boost.restore(s);
            Notifier.clear(app);
            runOnUiThread(() -> log("Defaults restored."));
        }, e -> runOnUiThread(() -> log("Error: " + e)));
    }

    private void onPermission() {
        if (!ShizukuHelper.running()) {
            Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
            if (i != null) startActivity(i); else log("Shizuku is not installed.");
        } else {
            Shizuku.requestPermission(REQ_SHIZUKU);
        }
    }

    // ---------- status ----------
    private void refresh() {
        boolean run = ShizukuHelper.running();
        boolean ok = ShizukuHelper.granted();
        int uid = ShizukuHelper.serverUid();
        String mode = uid == 0 ? "root" : uid == 2000 ? "ADB (shell)" : "—";

        status.setText(line("Shizuku running", run) + line("Permission granted", ok)
                + line("ADB binder active", run && uid == 2000 || uid == 0) + "Mode: " + mode);
        bPerm.setVisibility(ok ? View.GONE : View.VISIBLE);
        bPerm.setText(run ? "Grant Shizuku permission" : "Open Shizuku");
        bBoost.setEnabled(ok);
        bRestore.setEnabled(ok);
    }

    private static String line(String label, boolean v) { return (v ? "● " : "○ ") + label + "\n"; }
    private void log(String s) { log.setText(s); }

    // ---------- UI (plain Views, no XML, no AppCompat) ----------
    private void buildUi() {
        int p = dp(20);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(p, dp(48), p, p);
        root.setFitsSystemWindows(true);

        TextView title = text("GameBoost", 24, Color.WHITE, true);
        root.addView(title);
        root.addView(text("CODM performance profile via Shizuku", 13, DIM, false));

        status = text("", 14, Color.WHITE, false);
        status.setTypeface(Typeface.MONOSPACE);
        status.setBackgroundColor(CARD);
        status.setPadding(p, p, p, p);
        root.addView(status, lp(dp(20)));

        bPerm = button("Grant Shizuku permission", CARD);
        bPerm.setOnClickListener(v -> onPermission());
        root.addView(bPerm, lp(dp(12)));

        bBoost = button("Boost & Launch CODM", ACCENT);
        bBoost.setTextColor(Color.BLACK);
        bBoost.setOnClickListener(v -> onBoost());
        root.addView(bBoost, lp(dp(12)));

        bRestore = button("Restore Defaults", CARD);
        bRestore.setOnClickListener(v -> onRestore());
        root.addView(bRestore, lp(dp(12)));

        log = text("", 12, DIM, false);
        root.addView(log, lp(dp(16)));

        setContentView(root);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String s, int bg) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(bg); b.setGravity(Gravity.CENTER);
        return b;
    }

    private LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        l.topMargin = topMargin;
        return l;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
