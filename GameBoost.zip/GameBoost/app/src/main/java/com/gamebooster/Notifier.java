package com.gamebooster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

final class Notifier {
    private static final int ID = 1;
    private static final String CH = "session";

    static void show(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CH, "Game session", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, new Intent(c, RestoreReceiver.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_menu_revert)
                .setContentTitle("Boost active")
                .setContentText("Tap to restore resolution & blur")
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(0, "Restore Defaults", pi).build())
                .setOngoing(true)
                .build();
        nm.notify(ID, n);
    }

    static void clear(Context c) {
        c.getSystemService(NotificationManager.class).cancel(ID);
    }
}
