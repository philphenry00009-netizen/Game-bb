package com.gamebooster;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class RestoreReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        final Context app = c.getApplicationContext();
        final PendingResult pr = goAsync();
        ShizukuHelper.with(s -> {
            Boost.restore(s);
            Notifier.clear(app);
            pr.finish();
        }, e -> pr.finish());
    }
}
